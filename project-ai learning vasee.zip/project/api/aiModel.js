export function getAIResponse(question) {
  const lowerQuestion = question.toLowerCase();

  const knowledgeBase = {
    html: {
      keywords: ['html', 'markup', 'tag', 'element', 'webpage'],
      response: 'HTML (HyperText Markup Language) is the standard markup language for creating web pages. It uses tags like <div>, <p>, <h1>, etc., to structure content. HTML provides the skeleton of a webpage, defining elements such as headings, paragraphs, links, and images.'
    },
    css: {
      keywords: ['css', 'style', 'styling', 'design', 'color', 'layout'],
      response: 'CSS (Cascading Style Sheets) is used to style and layout web pages. It controls colors, fonts, spacing, and positioning of HTML elements. CSS can be applied inline, internally, or externally through separate .css files. Modern CSS includes features like Flexbox and Grid for responsive layouts.'
    },
    javascript: {
      keywords: ['javascript', 'js', 'programming', 'script', 'function', 'variable'],
      response: 'JavaScript is a versatile programming language that makes web pages interactive. It can manipulate HTML and CSS, handle events, validate forms, and communicate with servers. JavaScript runs in the browser and can also run on servers using Node.js. Key concepts include variables, functions, loops, and objects.'
    },
    python: {
      keywords: ['python', 'py', 'programming language'],
      response: 'Python is a high-level, interpreted programming language known for its simplicity and readability. It\'s widely used in web development, data science, artificial intelligence, and automation. Python uses indentation for code blocks and has a vast ecosystem of libraries and frameworks.'
    },
    database: {
      keywords: ['database', 'sql', 'data', 'storage', 'query'],
      response: 'Databases are organized collections of data that can be easily accessed, managed, and updated. SQL databases like MySQL and PostgreSQL use structured tables, while NoSQL databases like MongoDB use flexible document structures. Databases are essential for storing user information, content, and application data.'
    },
    api: {
      keywords: ['api', 'rest', 'endpoint', 'request', 'response'],
      response: 'An API (Application Programming Interface) is a set of rules and protocols that allows different software applications to communicate. REST APIs use HTTP methods (GET, POST, PUT, DELETE) to perform operations. APIs enable frontend applications to interact with backend servers and retrieve or send data.'
    },
    react: {
      keywords: ['react', 'component', 'jsx', 'frontend framework'],
      response: 'React is a popular JavaScript library for building user interfaces. It uses a component-based architecture, where UI is broken down into reusable pieces. React uses JSX syntax, which combines JavaScript with HTML-like code. Key features include virtual DOM, hooks, and state management.'
    },
    nodejs: {
      keywords: ['node', 'nodejs', 'backend', 'server', 'express'],
      response: 'Node.js is a JavaScript runtime built on Chrome\'s V8 engine that allows JavaScript to run on servers. It\'s event-driven and non-blocking, making it efficient for handling multiple requests. Express.js is a popular framework for building web applications and APIs with Node.js.'
    },
    algorithm: {
      keywords: ['algorithm', 'sorting', 'searching', 'complexity'],
      response: 'An algorithm is a step-by-step procedure for solving a problem or performing a task. Common algorithms include sorting (bubble sort, quick sort), searching (binary search, linear search), and graph algorithms. Algorithm efficiency is measured using Big O notation for time and space complexity.'
    },
    datastructure: {
      keywords: ['data structure', 'array', 'linked list', 'tree', 'stack', 'queue'],
      response: 'Data structures are ways of organizing and storing data efficiently. Common data structures include arrays (fixed-size collections), linked lists (connected nodes), stacks (LIFO), queues (FIFO), trees (hierarchical), and hash tables (key-value pairs). Choosing the right data structure is crucial for program efficiency.'
    },
    git: {
      keywords: ['git', 'version control', 'commit', 'branch', 'github'],
      response: 'Git is a distributed version control system that tracks changes in code over time. Key commands include git init, git add, git commit, git push, and git pull. Branches allow parallel development, and GitHub/GitLab provide hosting for Git repositories with collaboration features.'
    },
    responsive: {
      keywords: ['responsive', 'mobile', 'media query', 'viewport'],
      response: 'Responsive design ensures websites work well on all devices and screen sizes. Techniques include using flexible layouts with CSS Grid or Flexbox, media queries to apply different styles based on screen width, and relative units like percentages and viewport units (vw, vh). Mobile-first design is a common approach.'
    }
  };

  for (const [topic, data] of Object.entries(knowledgeBase)) {
    for (const keyword of data.keywords) {
      if (lowerQuestion.includes(keyword)) {
        return data.response;
      }
    }
  }

  if (lowerQuestion.includes('what') || lowerQuestion.includes('how') || lowerQuestion.includes('why')) {
    return 'That\'s an interesting question! While I specialize in web development and programming topics like HTML, CSS, JavaScript, Python, databases, APIs, and algorithms, I might not have specific information about that topic. Could you ask something related to programming or web development?';
  }

  if (lowerQuestion.includes('hello') || lowerQuestion.includes('hi')) {
    return 'Hello! I\'m your AI Learning Assistant. I can help you with questions about web development, programming languages, databases, algorithms, and more. What would you like to learn today?';
  }

  if (lowerQuestion.includes('help') || lowerQuestion.includes('?')) {
    return 'I can help you learn about various programming topics including HTML, CSS, JavaScript, Python, databases, APIs, React, Node.js, algorithms, data structures, Git, and responsive design. Just ask me a question about any of these topics!';
  }

  return 'I\'m an AI Learning Assistant focused on programming and web development. I can answer questions about HTML, CSS, JavaScript, Python, databases, APIs, frameworks like React and Node.js, algorithms, data structures, Git, and responsive design. Please ask me something related to these topics!';
}
