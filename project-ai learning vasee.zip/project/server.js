import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import path from 'path';
import { fileURLToPath } from 'url';
import { getAIResponse } from './api/aiModel.js';
import { createClient } from '@supabase/supabase-js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY || '';
const supabase = createClient(supabaseUrl, supabaseKey);

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('username', username)
      .eq('password', password)
      .maybeSingle();

    if (error) throw error;

    if (data) {
      res.json({ success: true, user: { id: data.id, username: data.username } });
    } else {
      res.json({ success: false, message: 'Invalid username or password' });
    }
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

app.post('/api/chat', async (req, res) => {
  const { question, userId } = req.body;

  if (!question) {
    return res.status(400).json({ error: 'Question is required' });
  }

  try {
    const answer = getAIResponse(question);

    if (userId) {
      await supabase.from('chat_history').insert({
        user_id: userId,
        question,
        answer
      });
    }

    res.json({ answer });
  } catch (error) {
    console.error('Chat error:', error);
    res.status(500).json({ error: 'Failed to process question' });
  }
});

app.get('/api/quiz', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('quiz_questions')
      .select('*')
      .limit(5);

    if (error) throw error;

    if (data && data.length > 0) {
      res.json({ questions: data });
    } else {
      res.json({ questions: getDefaultQuestions() });
    }
  } catch (error) {
    console.error('Quiz error:', error);
    res.json({ questions: getDefaultQuestions() });
  }
});

app.post('/api/quiz/submit', async (req, res) => {
  const { answers, userId } = req.body;

  try {
    const { data: questions } = await supabase
      .from('quiz_questions')
      .select('*')
      .limit(5);

    let score = 0;
    const results = [];

    if (questions && questions.length > 0) {
      questions.forEach((question, index) => {
        const isCorrect = answers[index] === question.correct_answer;
        if (isCorrect) score++;
        results.push({
          question: question.question,
          correct: isCorrect,
          correctAnswer: question.correct_answer
        });
      });
    } else {
      const defaultQuestions = getDefaultQuestions();
      defaultQuestions.forEach((question, index) => {
        const isCorrect = answers[index] === question.correctAnswer;
        if (isCorrect) score++;
        results.push({
          question: question.question,
          correct: isCorrect,
          correctAnswer: question.correctAnswer
        });
      });
    }

    if (userId) {
      await supabase.from('quiz_results').insert({
        user_id: userId,
        score,
        total: results.length
      });
    }

    res.json({ score, total: results.length, results });
  } catch (error) {
    console.error('Quiz submit error:', error);
    res.status(500).json({ error: 'Failed to submit quiz' });
  }
});

function getDefaultQuestions() {
  return [
    {
      id: 1,
      question: 'What does HTML stand for?',
      options: ['Hyper Text Markup Language', 'High Tech Modern Language', 'Home Tool Markup Language', 'Hyperlinks and Text Markup Language'],
      correctAnswer: 0
    },
    {
      id: 2,
      question: 'Which programming language is known as the language of the web?',
      options: ['Python', 'Java', 'JavaScript', 'C++'],
      correctAnswer: 2
    },
    {
      id: 3,
      question: 'What does CSS stand for?',
      options: ['Creative Style Sheets', 'Cascading Style Sheets', 'Computer Style Sheets', 'Colorful Style Sheets'],
      correctAnswer: 1
    },
    {
      id: 4,
      question: 'Which of these is a JavaScript framework?',
      options: ['Django', 'Flask', 'React', 'Laravel'],
      correctAnswer: 2
    },
    {
      id: 5,
      question: 'What is the purpose of the <head> tag in HTML?',
      options: ['To display the main content', 'To contain metadata and links', 'To create headers', 'To define the footer'],
      correctAnswer: 1
    }
  ];
}

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
