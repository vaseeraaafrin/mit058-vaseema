/*
  # Create AI Learning Assistant Database Schema

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `username` (text, unique)
      - `password` (text)
      - `created_at` (timestamptz)
    
    - `chat_history`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `question` (text)
      - `answer` (text)
      - `created_at` (timestamptz)
    
    - `quiz_questions`
      - `id` (uuid, primary key)
      - `question` (text)
      - `options` (jsonb array of options)
      - `correct_answer` (integer, index of correct option)
      - `created_at` (timestamptz)
    
    - `quiz_results`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `score` (integer)
      - `total` (integer)
      - `created_at` (timestamptz)

  2. Security
    - Enable RLS on all tables
    - Users can read their own data
    - Users can insert their own chat history and quiz results
    - Quiz questions are readable by all authenticated users
*/

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  username text UNIQUE NOT NULL,
  password text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS chat_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  question text NOT NULL,
  answer text NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question text NOT NULL,
  options jsonb NOT NULL,
  correct_answer integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS quiz_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  score integer NOT NULL DEFAULT 0,
  total integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own profile"
  ON users FOR SELECT
  USING (true);

CREATE POLICY "Anyone can create a user account"
  ON users FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Users can view own chat history"
  ON chat_history FOR SELECT
  USING (true);

CREATE POLICY "Users can create chat history"
  ON chat_history FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Anyone can view quiz questions"
  ON quiz_questions FOR SELECT
  USING (true);

CREATE POLICY "Users can view own quiz results"
  ON quiz_results FOR SELECT
  USING (true);

CREATE POLICY "Users can create quiz results"
  ON quiz_results FOR INSERT
  WITH CHECK (true);

INSERT INTO users (username, password) VALUES 
  ('demo', 'demo123'),
  ('student', 'student123')
ON CONFLICT (username) DO NOTHING;

INSERT INTO quiz_questions (question, options, correct_answer) VALUES 
  ('What does HTML stand for?', '["Hyper Text Markup Language", "High Tech Modern Language", "Home Tool Markup Language", "Hyperlinks and Text Markup Language"]'::jsonb, 0),
  ('Which programming language is known as the language of the web?', '["Python", "Java", "JavaScript", "C++"]'::jsonb, 2),
  ('What does CSS stand for?', '["Creative Style Sheets", "Cascading Style Sheets", "Computer Style Sheets", "Colorful Style Sheets"]'::jsonb, 1),
  ('Which of these is a JavaScript framework?', '["Django", "Flask", "React", "Laravel"]'::jsonb, 2),
  ('What is the purpose of the <head> tag in HTML?', '["To display the main content", "To contain metadata and links", "To create headers", "To define the footer"]'::jsonb, 1)
ON CONFLICT (id) DO NOTHING;
